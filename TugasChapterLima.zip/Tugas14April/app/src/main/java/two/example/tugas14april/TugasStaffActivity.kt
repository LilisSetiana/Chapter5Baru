package two.example.tugas14april

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_2.*
import kotlinx.android.synthetic.main.activity_main.rv_staff
import retrofit2.Call
import retrofit2.Response
import two.example.tugas14april.Adapter.StaffAdapter
import two.example.tugas14april.Model.GetAllStafResponseItem
import two.example.tugas14april.Network.ApiClient

class TugasStaffActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_staff)


        getDataStaff()

        fab_tambah_staff.setOnClickListener{
            startActivity(Intent(this, TugasStaffActivity::class.java))
        }
    }

    fun getDataStaff() {
        ApiClient.instance.getAllStaf()
            .enqueue(object : retrofit2.Callback<List<GetAllStafResponseItem>> {
                override fun onResponse(
                    call: Call<List<GetAllStafResponseItem>>,
                    response: Response<List<GetAllStafResponseItem>>
                ) {
                    if (response.isSuccessful) {
                        val dataStaff = response.body()
                        val adapter = StaffAdapter(dataStaff!!)
                        val LayoutManager = LinearLayoutManager(
                            applicationContext,LinearLayoutManager.VERTICAL,
                            false
                        )
                        rv_staff.layoutManager = LayoutManager
                        rv_staff.adapter = adapter
                    } else {
                        AlertDialog.Builder(this@TugasStaffActivity)
                           .setTitle("Eror")
                           .setMessage(response.message())
                           .setCancelable(false)
                           .show()
                    }
                }

                override fun onFailure(call: Call<List<GetAllStafResponseItem>>, t: Throwable) {
                    AlertDialog.Builder(this@TugasStaffActivity)
                        .setTitle("Eror")
                        .setMessage(t.message)
                        .setCancelable(false)
                        .show()
                }
                })

            }

    override fun onResume() {
        super.onResume()
        getDataStaff()
    }

    override fun onDestroy() {
        super.onDestroy()
    }
    }
