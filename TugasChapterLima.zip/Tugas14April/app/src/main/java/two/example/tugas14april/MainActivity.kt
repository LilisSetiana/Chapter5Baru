package two.example.tugas14april

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Response
import two.example.tugas14april.Adapter.StaffAdapter
import two.example.tugas14april.Model.GetAllStafResponseItem
import two.example.tugas14april.Network.ApiClient

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

getDataStaff()
    }

    fun getDataStaff() {
        ApiClient.instance.getAllStaf()
            .enqueue(object : retrofit2.Callback<List<GetAllStafResponseItem>> {
                override fun onResponse(
                    call: Call<List<GetAllStafResponseItem>>,
                    response: Response<List<GetAllStafResponseItem>>
                ) {
                    if (response.isSuccessful) {
                        val dataStaff = response.body()
                        rv_staff.layoutManager = LinearLayoutManager(
                            applicationContext,
                            LinearLayoutManager.VERTICAL,
                            false
                        )
                        rv_staff.adapter = StaffAdapter(dataStaff!!)
                    } else {
                        Toast.makeText(this@MainActivity, response.message(), Toast.LENGTH_LONG)
                            .show()
                    }
                }

                override fun onFailure(call: Call<List<GetAllStafResponseItem>>, t: Throwable) {
                    Toast.makeText(this@MainActivity, t.message, Toast.LENGTH_LONG).show()
                }

            })
    }
}