package two.example.tugas14april.Network

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import two.example.tugas14april.Model.GetAllStafResponseItem
import two.example.tugas14april.Model.PostStaff
import two.example.tugas14april.Model.PostStaffResponse

interface ApiService {

    @GET("staf")
    fun getAllStaf() : Call<List<GetAllStafResponseItem>>

    @POST("staf")
    fun postStaff(@Body req: PostStaff) : Call<PostStaffResponse>
}