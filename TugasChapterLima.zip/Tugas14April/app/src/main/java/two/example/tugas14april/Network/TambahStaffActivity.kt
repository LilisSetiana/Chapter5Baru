package two.example.tugas14april.Network

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_tambah_staff.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import two.example.tugas14april.Model.PostStaff
import two.example.tugas14april.Model.PostStaffResponse
import two.example.tugas14april.R

class TambahStaffActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_staff)

        btn_tambah_staff.setOnClickListener {
            PostStaff(
                et_email_baru.text.toString(),
                et_image_baru.text.toString(),
                et_nama_baru.text.toString()
            )

            finish()

        }
    }

    fun PostStaff(email: String, image: String, name: String): PostStaff {
        ApiClient.instance.postStaff(PostStaff(email, image, name))
            .enqueue(object : Callback<PostStaffResponse> {
                override fun onResponse(
                    call: Call<PostStaffResponse>,
                    response: Response<PostStaffResponse>

                ) {
                    if (response.isSuccessful)
                        Toast.makeText(
                            this@TambahStaffActivity, response.message(), Toast.LENGTH_LONG
                        ).show()
                }

                override fun onFailure(call: Call<PostStaffResponse>, t: Throwable) {
                    Toast.makeText(this@TambahStaffActivity, t.message, Toast.LENGTH_LONG)
                        .show()
                }
            })
    }
}









