package two.example.tugas14april.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_staff_adapter.view.*
import two.example.tugas14april.Model.GetAllStafResponseItem
import two.example.tugas14april.R

class StaffAdapter(private val datastaff: List<GetAllStafResponseItem>) : RecyclerView.Adapter<StaffAdapter.ViewHolder>(){

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StaffAdapter.ViewHolder {
        val itemview = LayoutInflater.from(parent.context).inflate(R.layout.item_staff_adapter, parent, false)
        return ViewHolder(itemview)
    }

    override fun onBindViewHolder(holder: StaffAdapter.ViewHolder, position: Int) {
        holder.itemView.nama_staf_tv.text = datastaff[position].name
        holder.itemView.tanggal_tv.text = datastaff[position].createdAt
        holder.itemView.email_tv.text = datastaff[position].email

    }

    override fun getItemCount(): Int {
       return datastaff.size
    }
}