package two.example.tugas14april.Model


import com.google.gson.annotations.SerializedName

class GetAllStafResponse : ArrayList<GetAllStafResponseItem>()